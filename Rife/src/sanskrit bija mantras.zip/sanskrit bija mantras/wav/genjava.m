# gen
pkg load all;

d=dir("*wav");
for i=1:numel(d)
	name=d(i).name;
	printf("new BMform(\"%s\",\t\t", name(1:length(name)-4));
	[p,f]=formants(name);
	printf("new double[]{ ");
	for j=1:4
		printf("%.1f, ",f(j));
	endfor
	printf("%.1f},\tnew double[]{ ", f(5));
	for j=1:4
		printf("%d, ", int32(p(j) * 2^15));
	endfor
	printf("%d}),\n", int32(p(5) * 2^15));
endfor

