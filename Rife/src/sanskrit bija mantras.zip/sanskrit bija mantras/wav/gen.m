# gen
pkg load all;

d=dir("*wav");
for i=1:numel(d)
	name=d(i).name;
	disp(name);
	[p,f]=formants(name);
	for j=1:5
		printf("%.1f\t%d\n",f(j), int32(p(j) * 2^15));
	endfor
endfor

