# calc formants of an wav input file
# frm = formants in Hz
# pwr = power in db
#

function [ pwr, frm ] = formants(file) 

	[x,Fs]=wavread(file);

	x1 = x.*hamming(length(x));

	preemph = [1 0.63];
	x1 = filter(1,preemph,x1);
	
	#Markel and Gray (1976, pp 154-156) recommend, for LPC speech analysis, choosing a number of coefficients (filter order "M") 
	# equal to the sampling rate in kHz, plus 4 or 5 additional coefficients.

	ncoeff=4+Fs/1000;
	A = lpc(x1,ncoeff);
	rts = roots(A);

	rts = rts(imag(rts)>=0);
	angz = atan2(imag(rts),real(rts));

	[frqs,indices] = sort(angz.*(Fs/(2*pi)));
	bw = -1/2*(Fs/(2*pi))*log(abs(rts(indices)));

	nn = 1;
	for kk = 1:length(frqs)
    		if (frqs(kk) > 90 && bw(kk) <400)
        		frm(nn) = frqs(kk);
        		nn = nn+1;
    		end
	end
	frm=frm(:);

	[h,f]=freqz(1,A,max(frm)+1,Fs);
	h=abs(h);
	h = h ./ ( max(h)-min(h) );
	
	# h=20*log10(abs(h)+eps); # plot(f,h);
	
	pwr=h(int32(frm));
	[pwr ixs]=sort(pwr,'descend');
	frm=frm(ixs);
end

